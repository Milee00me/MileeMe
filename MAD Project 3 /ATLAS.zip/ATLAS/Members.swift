//
//  Members.swift
//  ATLAS
//
//  Created by Milee Shrestha on 12/11/14.
//  Copyright (c) 2014 Milee Shrestha. All rights reserved.
//

import Foundation

class Members {
    
    
    var membersData = NSMutableDictionary()
    var members = [String]()
    
    /*
        var imageName = "blank"
    
    init(imageName: String)
    {
        
        self.imageName = imageName
    }
    */
    
}
